Get-ChildItem 'F:\MCProject\astral_dice_multiloader\neoforge-1.21.1\run\1.21.1\mods' -Filter '*.jar' | ForEach-Object {
    Write-Output ($_.Name + ' => ' + ($_.Name -match 'IMBlocker|sodium|iris'))
}
