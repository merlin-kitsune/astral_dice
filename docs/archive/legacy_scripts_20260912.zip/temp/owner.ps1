$out = 'F:\MCProject\astral_dice_multiloader\temp\owner.txt'
$L = New-Object System.Collections.Generic.List[string]
function W($s) { $script:L.Add([string]$s) }
W ("=== owner probe {0} ===" -f (Get-Date -Format o))

function ShowDrv([string]$svcName) {
    $svc = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\$svcName" -ErrorAction SilentlyContinue
    if (-not $svc) { W ("[{0}] <service not present>" -f $svcName); return }
    $img = [string]$svc.ImagePath
    $p = $img -replace '^\\\?\?\\','' -replace '^\\SystemRoot\\','C:\WINDOWS\' -replace '^System32\\','C:\WINDOWS\System32\' -replace '^system32\\','C:\WINDOWS\system32\'
    W ("[{0}]  ImagePath={1}" -f $svcName, $img)
    W ("        resolved={0} exists={1}" -f $p, (Test-Path -LiteralPath $p))
    if (Test-Path -LiteralPath $p) {
        try {
            $vi = (Get-Item -LiteralPath $p).VersionInfo
            W ("        company={0}" -f $vi.CompanyName)
            W ("        product={0} | desc={1} | ver={2}" -f $vi.ProductName, $vi.FileDescription, $vi.FileVersion)
            W ("        copyright={0}" -f $vi.LegalCopyright)
            $s = Get-AuthenticodeSignature -LiteralPath $p -ErrorAction SilentlyContinue
            if ($s) { W ("        sig={0} | signer={1}" -f $s.Status, $s.SignerCertificate.Subject) }
        } catch { W ("        ERR vi: {0}" -f $_) }
    }
}

W ""
W "--- 未归属的过滤驱动 ---"
foreach ($n in 'UnionFS','bfs','wcifs','FileCrypt','FileInfo','storqosflt','bindflt','CldFlt','gameflt','NeSigVerify','hhdusbmc64','gvinput','gvinputmf','luafv','UCPD') { ShowDrv $n }

W ""
W "--- 这些驱动的相关文件一起看（同目录/同厂商）---"
foreach ($n in 'UnionFS','bfs') {
    $svc = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\$n" -ErrorAction SilentlyContinue
    if (-not $svc) { continue }
    $p = [string]$svc.ImagePath -replace '^\\SystemRoot\\','C:\WINDOWS\'
    $d = Split-Path $p -Parent
    W ("[{0}] dir={1}" -f $n, $d)
    try { W ((Get-ChildItem $d -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'union|bfs' } | Select-Object Name,Length,LastWriteTime | Format-Table -AutoSize | Out-String)) } catch {}
    W ("        service reg: Group={0} Start={1} Type={2}" -f $svc.Group, $svc.Start, $svc.Type)
}

W ""
W "=== DONE ==="
$L -join "`r`n" | Set-Content -LiteralPath $out -Encoding utf8
