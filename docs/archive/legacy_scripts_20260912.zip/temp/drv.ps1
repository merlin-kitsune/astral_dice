$out = 'F:\MCProject\astral_dice_multiloader\temp\drv.txt'
$L = New-Object System.Collections.Generic.List[string]
function W($s) { $script:L.Add([string]$s) }

W ("=== driver ownership probe {0} ===" -f (Get-Date -Format o))

W ""
W "--- ALL running drivers whose CompanyName is NOT Microsoft ---"
$rows = @()
foreach ($d in (Get-CimInstance Win32_SystemDriver -ErrorAction SilentlyContinue | Where-Object { $_.State -eq 'Running' })) {
    $p = $d.PathName
    if (-not $p) { continue }
    $p = $p -replace '^\\\?\?\\', ''
    if (-not (Test-Path -LiteralPath $p)) { continue }
    try { $vi = (Get-Item -LiteralPath $p).VersionInfo } catch { continue }
    if ($vi.CompanyName -and $vi.CompanyName -match 'Microsoft') { continue }
    $sig = ''
    try { $sig = (Get-AuthenticodeSignature -LiteralPath $p -ErrorAction SilentlyContinue).SignerCertificate.Subject } catch {}
    $rows += [pscustomobject]@{
        Name    = $d.Name
        Company = $vi.CompanyName
        Product = $vi.ProductName
        Ver     = $vi.FileVersion
        Path    = $p
        Signer  = ($sig -replace '^CN=','' -replace ',.*$','')
    }
}
W (($rows | Sort-Object Company,Name | Format-Table -AutoSize | Out-String -Width 300))

W ""
W "--- 重点嫌疑驱动的详细信息 ---"
foreach ($n in 'UnionFS','VirtualFileSystem2','Filetrace','Revoflt','EAAntiCheat','gameflt','klids','klupd_K4W-21-25_arkmon','bfs') {
    $svc = Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\$n" -ErrorAction SilentlyContinue
    if ($svc) {
        W ("[{0}] image={1}" -f $n, $svc.ImagePath)
        $inst = Get-ChildItem "HKLM:\SYSTEM\CurrentControlSet\Services\$n\Instances" -ErrorAction SilentlyContinue
        foreach ($i in $inst) {
            $ip = Get-ItemProperty $i.PSPath -ErrorAction SilentlyContinue
            W ("      instance={0} altitude={1} flags={2}" -f $i.PSChildName, $ip.Altitude, $ip.Flags)
        }
    } else { W ("[{0}] <not present>" -f $n) }
    if ($svc -and $svc.ImagePath) {
        $ip2 = $svc.ImagePath -replace '^\\\?\?\\','' -replace '^system32','C:\WINDOWS\system32'
        if (Test-Path -LiteralPath $ip2) {
            $vi = (Get-Item -LiteralPath $ip2).VersionInfo
            W ("      company={0} | product={1} | desc={2} | ver={3}" -f $vi.CompanyName, $vi.ProductName, $vi.FileDescription, $vi.FileVersion)
        }
    }
}

W ""
W "--- 已安装程序（可能相关）---"
try {
    $paths = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    $apps = foreach ($pp in $paths) { Get-ItemProperty $pp -ErrorAction SilentlyContinue }
    $apps2 = $apps | Where-Object { $_.DisplayName -match 'DeskBox|Union|Revo|EA |AntiCheat|Myth|Cool|Everything|OneDrive|Kaspersky|Netease|GameViewer|MSI' } |
        Select-Object DisplayName,DisplayVersion,Publisher,InstallLocation
    W (($apps2 | Sort-Object DisplayName | Format-Table -AutoSize | Out-String -Width 260))
} catch { W "ERR apps: $_" }

W ""
W "=== DONE ==="
$L -join "`r`n" | Set-Content -LiteralPath $out -Encoding utf8
