# 决定性问题：把 git 放到「工具沙箱之外」的进程里运行，问题还在吗？
$out = 'F:\MCProject\astral_dice_multiloader\temp\outside.txt'
$L = New-Object System.Collections.Generic.List[string]
function W($s) { $script:L.Add([string]$s) }
W ("=== sandbox-escape probe {0} ===" -f (Get-Date -Format o))

$G = 'C:\Program Files\Git\cmd\git.exe'
$R = "F:\MCProject\_rpout_$(Get-Date -Format 'HHmmss')"
$bat = 'F:\MCProject\astral_dice_multiloader\temp\out_run.cmd'
$log = 'F:\MCProject\astral_dice_multiloader\temp\out_run.log'

$body = @"
@echo off
"$G" -C "$R" init -q
"$G" -C "$R" config user.email t@t
"$G" -C "$R" config user.name t
echo x > "$R\f.txt"
"$G" -C "$R" add -A
"$G" -C "$R" commit -q -m i
"$G" -C "$R" rev-parse HEAD > "$R\head.txt"
echo === before-update-ref ===
"$G" -C "$R" update-ref refs/heads/esc/deep HEAD
echo rc=%errorlevel%
echo === after-update-ref ===
dir /b /s "$R\.git\refs\heads" 2>nul
"@
Set-Content -LiteralPath $bat -Value $body -Encoding ascii
New-Item -ItemType Directory -Path $R -Force | Out-Null

W "repo = $R"

# --- 方式 1：WMI 创建进程（由 WmiPrvSE 服务启动，脱离本工具沙箱的进程树） ---
W ""
W "--- [1] WMI Win32_Process.Create ---"
try {
    $r1 = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = "cmd.exe /c `"$bat`" > `"$log`" 2>&1" }
    W ("ReturnValue={0} ProcessId={1}" -f $r1.ReturnValue, $r1.ProcessId)
} catch { W "ERR wmi: $_" }
Start-Sleep -Seconds 6
$p1 = "$R\.git\refs\heads\esc\deep"
W ("file refs/heads/esc/deep = {0}" -f (Test-Path -LiteralPath $p1))
W ("other refs under refs/heads: {0}" -f ((Get-ChildItem "$R\.git\refs\heads" -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) -join ', '))
if (Test-Path -LiteralPath $log) { W "log:"; W (Get-Content -LiteralPath $log -Raw) }

# --- 方式 2：计划任务（由 Task Scheduler 服务启动） ---
W ""
W "--- [2] schtasks (Task Scheduler service) ---"
$R2 = $R + "_b"
New-Item -ItemType Directory -Path $R2 -Force | Out-Null
$bat2 = 'F:\MCProject\astral_dice_multiloader\temp\out_run2.cmd'
$log2 = 'F:\MCProject\astral_dice_multiloader\temp\out_run2.log'
$body2 = $body.Replace($R, $R2)
Set-Content -LiteralPath $bat2 -Value $body2 -Encoding ascii
$tn = 'rpOutsideProbe'
try {
    $a = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/c `"$bat2`" > `"$log2`" 2>&1"
    Register-ScheduledTask -TaskName $tn -Action $a -Force -ErrorAction Stop | Out-Null
    Start-ScheduledTask -TaskName $tn -ErrorAction Stop
    W "scheduled task started"
} catch { W "ERR schtasks: $_" }
Start-Sleep -Seconds 8
$p2 = "$R2\.git\refs\heads\esc\deep"
W ("file refs/heads/esc/deep = {0}" -f (Test-Path -LiteralPath $p2))
if (Test-Path -LiteralPath $log2) { W "log2:"; W (Get-Content -LiteralPath $log2 -Raw) }
try { Unregister-ScheduledTask -TaskName $tn -Confirm:$false -ErrorAction SilentlyContinue } catch {}

W ""
W "=== DONE ==="
$L -join "`r`n" | Set-Content -LiteralPath $out -Encoding utf8
