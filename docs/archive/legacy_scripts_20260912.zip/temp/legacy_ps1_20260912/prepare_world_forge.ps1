# 自动化测试 - 准备超平坦生存测试世界(forge-1.20.1 版)
# 1. 删除旧测试存档
# 2. 配置 server.properties(超平坦/生存/开启命令方块)
# 3. 通过 runServer 自动生成世界,完成后停止服务器
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common_forge.ps1"
$root = $Root
$run = $RunDir
$worldName = $WorldName

Write-Host "[1/4] 删除之前创建的世界(客户端存档 + 服务器残留)"
$clientSaves = Join-Path $run "saves"
$serverWorld = Join-Path $run $worldName
$clientWorld = Join-Path $clientSaves $worldName
if (Test-Path -LiteralPath $clientWorld) {
    Remove-Item -LiteralPath $clientWorld -Recurse -Force
}
if (Test-Path -LiteralPath $serverWorld) {
    Remove-Item -LiteralPath $serverWorld -Recurse -Force
}
if (-not (Test-Path -LiteralPath $clientSaves)) {
    New-Item -ItemType Directory -Path $clientSaves | Out-Null
}
$latestLog = Join-Path $run "logs\latest.log"
if (Test-Path -LiteralPath $latestLog) { Remove-Item -LiteralPath $latestLog -Force }

Write-Host "[2/4] 配置 server.properties(创造模式/允许命令/简单难度,首轮测试用创造避免被怪击杀)"
$props = Join-Path $run "server.properties"
$propContent = @"
#Minecraft server properties
online-mode=false
level-name=$worldName
level-type=flat
generator-settings=
gamemode=creative
difficulty=easy
spawn-protection=0
enable-command-block=true
max-players=1
allow-cheats=true
"@
Set-Content -LiteralPath $props -Value $propContent -Encoding ascii

# 取消失焦暂停(否则窗口失焦时游戏暂停,自动化注入无效)
$options = Join-Path $run "options.txt"
$optLines = New-Object System.Collections.Generic.List[string]
if (Test-Path -LiteralPath $options) {
    $optLines = [System.Collections.Generic.List[string]](Get-Content -LiteralPath $options | Where-Object { $_ -notmatch "^pauseOnLostFocus:" })
}
$optLines.Add("pauseOnLostFocus:false")
Set-Content -LiteralPath $options -Value $optLines -Encoding ascii
Write-Host "已取消失焦暂停: $options"

Write-Host "[3/4] 启动 runServer 生成世界..."
# Forge 服务器强制要求 eula.txt(NeoForge dev 自动接受,Forge 需显式写入)
$eula = Join-Path $run "eula.txt"
Set-Content -LiteralPath $eula -Value "eula=true" -Encoding ascii
Write-Host "已写入 eula.txt(eula=true)"
# 纯客户端模组在服务端会崩溃/挂起:生成世界期间临时移出 mods 目录
# (Embeddium/Oculus 的 META-INF/services(GraphicsBootstrapper)会被服务端发现并挂起启动;IMBlocker 崩溃)
# 注意:必须用普通 foreach 累积(ForEach-Object 脚本块内 += 不会写回外层作用域,恢复时会丢列表)
$clientOnlyMoved = @()
foreach ($modFile in Get-ChildItem (Join-Path $run "mods") -Filter "*.jar" -ErrorAction SilentlyContinue) {
    if ($modFile.Name -match "embeddium|oculus|IMBlocker|sodium|iris") {
        $bak = Join-Path $run ("__clientonly_bak__" + $modFile.Name)
        Move-Item -LiteralPath $modFile.FullName -Destination $bak -Force
        $clientOnlyMoved += $bak
        Write-Host "已临时移出客户端模组: $($modFile.Name)"
    }
}
$proc = Start-Process -FilePath (Join-Path $root "gradlew.bat") -ArgumentList ":forge-1.20.1:runServer","--console=plain" -WorkingDirectory $root -PassThru -WindowStyle Hidden
$deadline = (Get-Date).AddSeconds(180)
$done = $false
while ((Get-Date) -lt $deadline) {
    Start-Sleep -Seconds 5
    if (Test-Path -LiteralPath $latestLog) {
        try {
            $fs = [System.IO.File]::Open($latestLog, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
            $reader = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8)
            $content = $reader.ReadToEnd()
            $reader.Close(); $fs.Close()
            if ($content -match "Done \(") { $done = $true; break }
            if ($content -match "Exception|crash|FATAL") { Write-Host "服务器异常!"; break }
        } catch { }
    }
}
Write-Host "[4/4] 停止服务器,移动世界到客户端存档目录"
Get-Process -Name "java" -ErrorAction SilentlyContinue | Where-Object { $_.Path -match "zulu|java" } | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3
# 恢复临时移出的客户端模组
foreach ($bak in $clientOnlyMoved) {
    $orig = Join-Path (Join-Path $run "mods") ($bak -replace '^.*__clientonly_bak__', '')
    Move-Item -LiteralPath $bak -Destination $orig -Force
    Write-Host "已恢复客户端模组: $(Split-Path $orig -Leaf)"
}

# 服务器世界生成在 run/testworld,客户端读取 run/saves/testworld
if (Test-Path -LiteralPath $serverWorld) {
    if (Test-Path -LiteralPath $clientWorld) { Remove-Item -LiteralPath $clientWorld -Recurse -Force }
    Move-Item -LiteralPath $serverWorld -Destination $clientWorld
}

if ($done -and (Test-Path -LiteralPath (Join-Path $clientWorld "level.dat"))) {
    Write-Host "世界生成完成: $clientWorld"
    # 单人游戏"允许命令"需要 level.dat 的 Data.AllowCommands=1(服务器生成的世界默认未设置)
    Add-Type -TypeDefinition @"
using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Net;
public static class NbtFixForge {
    public static bool SetAllowCommands(string path, byte value) {
        byte[] gz = File.ReadAllBytes(path);
        MemoryStream ms = new MemoryStream();
        using (GZipStream g = new GZipStream(new MemoryStream(gz), CompressionMode.Decompress)) g.CopyTo(ms);
        byte[] data = ms.ToArray();
        int? modPos = null;
        try {
            using (BinaryReader br = new BinaryReader(new MemoryStream(data))) {
                br.ReadByte();
                int nameLen = IPAddress.NetworkToHostOrder(br.ReadInt16());
                br.ReadBytes(nameLen);
                ReadCompound(br, ref modPos);
            }
        } catch (Exception) { return false; }
        if (!modPos.HasValue) return false;
        data[modPos.Value] = value;
        MemoryStream outMs = new MemoryStream();
        using (GZipStream g = new GZipStream(outMs, CompressionMode.Compress, true)) g.Write(data, 0, data.Length);
        File.WriteAllBytes(path, outMs.ToArray());
        return true;
    }
    static void ReadCompound(BinaryReader br, ref int? modPos) {
        while (true) {
            byte t = br.ReadByte();
            if (t == 0) return;
            int nl = IPAddress.NetworkToHostOrder(br.ReadInt16());
            string name = Encoding.UTF8.GetString(br.ReadBytes(nl));
            switch (t) {
                case 1: if (name == "allowCommands") modPos = (int)br.BaseStream.Position; br.ReadByte(); break;
                case 2: br.ReadInt16(); break;
                case 3: br.ReadInt32(); break;
                case 4: br.ReadInt64(); break;
                case 5: br.ReadSingle(); break;
                case 6: br.ReadDouble(); break;
                case 7: int l7 = IPAddress.NetworkToHostOrder(br.ReadInt32()); br.ReadBytes(l7); break;
                case 8: int l8 = IPAddress.NetworkToHostOrder(br.ReadInt16()); br.ReadBytes(l8); break;
                case 9: byte et = br.ReadByte(); int el = IPAddress.NetworkToHostOrder(br.ReadInt32()); for (int i = 0; i < el; i++) SkipValue(br, et); break;
                case 10: ReadCompound(br, ref modPos); break;
                case 11: int l11 = IPAddress.NetworkToHostOrder(br.ReadInt32()); br.ReadBytes(l11 * 4); break;
                case 12: int l12 = IPAddress.NetworkToHostOrder(br.ReadInt32()); br.ReadBytes(l12 * 8); break;
            }
        }
    }
    static void SkipValue(BinaryReader br, byte t) {
        switch (t) {
            case 1: br.ReadByte(); break;
            case 2: br.ReadInt16(); break;
            case 3: br.ReadInt32(); break;
            case 4: br.ReadInt64(); break;
            case 5: br.ReadSingle(); break;
            case 6: br.ReadDouble(); break;
            case 7: int l = IPAddress.NetworkToHostOrder(br.ReadInt32()); br.ReadBytes(l); break;
            case 8: int sl = IPAddress.NetworkToHostOrder(br.ReadInt16()); br.ReadBytes(sl); break;
            case 9: byte et = br.ReadByte(); int el = IPAddress.NetworkToHostOrder(br.ReadInt32()); for (int i = 0; i < el; i++) SkipValue(br, et); break;
            case 10: SkipCompound(br); break;
            case 11: int l11 = IPAddress.NetworkToHostOrder(br.ReadInt32()); br.ReadBytes(l11 * 4); break;
            case 12: int l12 = IPAddress.NetworkToHostOrder(br.ReadInt32()); br.ReadBytes(l12 * 8); break;
        }
    }
    static void SkipCompound(BinaryReader br) {
        while (true) {
            byte t = br.ReadByte();
            if (t == 0) return;
            int nl = IPAddress.NetworkToHostOrder(br.ReadInt16());
            br.ReadBytes(nl);
            SkipValue(br, t);
        }
    }
}
"@
    $levelDat = Join-Path $clientWorld "level.dat"
    $fixed = [NbtFixForge]::SetAllowCommands($levelDat, 1)
    Write-Host "AllowCommands=1 设置: $fixed"
    Write-Host "PREPARE_OK"
} else {
    Write-Host "PREPARE_FAILED(世界未生成)"
    exit 1
}
