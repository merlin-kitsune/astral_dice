# gradlew 执行辅助脚本(forge-1.20.1 版)
# 规则: 单次执行最多 30 秒,超时后先检查输出是否已含 "BUILD SUCCESSFUL"(构建完成但进程未及时退出),
#       若已成功则强制终止进程树并验证产物 jar 后视为成功;否则强行终止进程树,再验证编译产物(jar 时间戳)
#       判断是否实际完成,未完成则重新执行,最多 3 次;3 次均失败则中止并返回退出码 2。
# 用法: .\scripts\test\run_gradle_forge.ps1 -Task "build" [-TimeoutSeconds 30] [-MaxRetries 3]
param(
    [Parameter(Mandatory = $true)][string]$Task,
    [int]$TimeoutSeconds = 30,
    [int]$MaxRetries = 3
)

$ErrorActionPreference = "Stop"
$root = "F:\MCProject\astral_dice_multiloader"
$jarDir = Join-Path $root "forge-1.20.1\build\libs"

function Get-JarStamp {
    $stamp = @{}
    if (Test-Path -LiteralPath $jarDir) {
        Get-ChildItem -LiteralPath $jarDir -Filter "*.jar" -ErrorAction SilentlyContinue | ForEach-Object {
            $stamp[$_.Name] = $_.LastWriteTimeUtc
        }
    }
    return $stamp
}

# 强制终止进程树(cmd 包装进程及其子进程)
function Stop-ProcessTree([int]$pid) {
    if ($pid -gt 0) {
        & taskkill.exe /PID $pid /T /F 2>$null | Out-Null
    }
}

for ($attempt = 1; $attempt -le $MaxRetries; $attempt++) {
    Write-Host "[尝试 $attempt/$MaxRetries] gradlew $Task (超时 ${TimeoutSeconds}s)"
    $outFile = Join-Path $env:TEMP "gradlew_forge_${Task}_$attempt.out"
    Remove-Item $outFile, "$outFile.err" -ErrorAction SilentlyContinue
    $stampBefore = Get-JarStamp

    $p = Start-Process -FilePath (Join-Path $root "gradlew.bat") -ArgumentList $Task, "--console=plain" `
        -WorkingDirectory $root -RedirectStandardOutput $outFile -RedirectStandardError "$outFile.err" `
        -PassThru -WindowStyle Hidden

    if (-not $p.WaitForExit($TimeoutSeconds * 1000)) {
        $content = ""
        if (Test-Path -LiteralPath $outFile) { $content = Get-Content -LiteralPath $outFile -Raw }
        if ($content -match "BUILD SUCCESSFUL") {
            Write-Host "输出已含 BUILD SUCCESSFUL,构建实际已完成(进程未及时退出),强制终止进程树..."
            Stop-ProcessTree $p.Id
            Start-Sleep -Seconds 2
            $stampAfter = Get-JarStamp
            $jarUpdated = $false
            foreach ($k in $stampAfter.Keys) {
                if (-not $stampBefore.ContainsKey($k) -or $stampAfter[$k] -gt $stampBefore[$k]) { $jarUpdated = $true }
            }
            if ($jarUpdated -or (Get-ChildItem -LiteralPath $jarDir -Filter "*.jar" -ErrorAction SilentlyContinue | Measure-Object).Count -gt 0) {
                Write-Host "产物 jar 已验证 ✅"
                exit 0
            }
            Write-Host "输出含 BUILD SUCCESSFUL 但未发现产物 jar,视为异常,准备重试..."
            continue
        }
        if ($content -match "BUILD FAILED") {
            Write-Host "BUILD FAILED ❌"
            Get-Content -LiteralPath $outFile | Select-Object -Last 15
            exit 1
        }
        Write-Host "超时(${TimeoutSeconds}s)且无构建结果,强行终止进程树..."
        Stop-ProcessTree $p.Id
        Start-Sleep -Seconds 2
        $stampAfter = Get-JarStamp
        $jarUpdated = $false
        foreach ($k in $stampAfter.Keys) {
            if (-not $stampBefore.ContainsKey($k) -or $stampAfter[$k] -gt $stampBefore[$k]) { $jarUpdated = $true }
        }
        if ($jarUpdated) {
            Write-Host "产物 jar 已更新,编译实际已完成 ✅ (进程未及时退出,视为成功)"
            exit 0
        }
        Write-Host "产物未更新,编译未完成,准备重试..."
        continue
    }

    $content = ""
    if (Test-Path -LiteralPath $outFile) { $content = Get-Content -LiteralPath $outFile -Raw }
    if ($content -match "BUILD SUCCESSFUL") {
        Write-Host "BUILD SUCCESSFUL ✅"
        exit 0
    }
    if ($content -match "BUILD FAILED") {
        Write-Host "BUILD FAILED ❌"
        Get-Content -LiteralPath $outFile | Select-Object -Last 15
        exit 1
    }
    Write-Host "进程退出但未识别到构建结果,视为未完成,准备重试..."
}

Write-Host "ERROR: $MaxRetries 次尝试均超时/失败,中止任务"
exit 2
