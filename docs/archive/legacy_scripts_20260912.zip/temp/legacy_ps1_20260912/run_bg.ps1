﻿# Background launcher: start a powershell script detached and return immediately.
# Usage: powershell -File run_bg.ps1 -Script <abs path> [-OutTag <tag>]
# Output files: F:\MCProject\astral_dice_multiloader\temp\<tag>.out / <tag>.err
param(
    [Parameter(Mandatory = $true)][string]$Script,
    [string]$OutTag = "bg"
)
$ErrorActionPreference = "Continue"
$dir = "F:\MCProject\astral_dice_multiloader\temp"
$out = Join-Path $dir ($OutTag + ".out")
$err = Join-Path $dir ($OutTag + ".err")
Remove-Item $out, $err -ErrorAction SilentlyContinue
$p = Start-Process -FilePath "powershell.exe" `
    -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", $Script) `
    -RedirectStandardOutput $out -RedirectStandardError $err -PassThru -WindowStyle Hidden
Write-Output ("PID=" + $p.Id)
Write-Output ("OUT=" + $out)
Write-Output ("ERR=" + $err)
