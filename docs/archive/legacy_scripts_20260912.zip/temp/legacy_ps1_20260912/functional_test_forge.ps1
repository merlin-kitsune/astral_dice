﻿# 自动化功能测试 - 阶段编排(forge-1.20.1 dice/卡牌功能)
# 阶段:
#   -Phase prepare : 重建超平坦创造 testworld(允许命令),复用 prepare_world_forge.ps1
#   -Phase launch  : 启动 runClient(quickplay=testworld),等待进入世界(不依赖旧 targetselector mixin 断言)
#   -Phase stop    : 关闭游戏(gradle daemon 保留)
#   -Phase report  : 收集日志/截图摘要到 scripts/test/reports/<日期>_function_1.20.1.md
# 无参数:依次执行 prepare → launch,随后打印 TC 执行说明(TC 注入步骤见 FLOW_1.20.1_functional.md)
param(
    [ValidateSet("prepare","launch","stop","report","")][string]$Phase = ""
)
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common_forge.ps1"

if ($Phase -eq "prepare" -or $Phase -eq "") {
    Write-Host "===== 阶段: prepare(testworld) ====="
    $seed = Join-Path $PSScriptRoot "resources/testworld-seed-1.20.1.zip"
    $clientWorld = Join-Path $RunDir "saves\$WorldName"
    if (Test-Path -LiteralPath $seed) {
        Write-Host "检测到种子世界,快速恢复(seed zip)"
        if (Test-Path -LiteralPath $clientWorld) { Remove-Item -LiteralPath $clientWorld -Recurse -Force }
        $serverWorld = Join-Path $RunDir $WorldName
        if (Test-Path -LiteralPath $serverWorld) { Remove-Item -LiteralPath $serverWorld -Recurse -Force }
        Expand-Archive -LiteralPath $seed -DestinationPath (Join-Path $RunDir "saves") -Force
        # 取消失焦暂停
        $options = Join-Path $RunDir "options.txt"
        $optLines = New-Object System.Collections.Generic.List[string]
        if (Test-Path -LiteralPath $options) {
            $optLines = [System.Collections.Generic.List[string]](Get-Content -LiteralPath $options | Where-Object { $_ -notmatch "^pauseOnLostFocus:" })
        }
        $optLines.Add("pauseOnLostFocus:false")
        Set-Content -LiteralPath $options -Value $optLines -Encoding ascii
        Write-Host "PREPARE_OK(seed restored: $clientWorld)"
    } else {
        Write-Host "无种子世界,走完整重建(注意:dev runServer 需临时排除 oculus,见 FLOW 文档)"
        & "$PSScriptRoot\prepare_world_forge.ps1"
        if ($LASTEXITCODE -ne 0) { throw "prepare 失败" }
    }
    if ($Phase -ne "") { exit 0 }
}

if ($Phase -eq "launch" -or $Phase -eq "") {
    Write-Host "===== 阶段: launch(runClient quickplay=testworld) ====="
    $latestLog = $LatestLog
    $crashReports = $CrashReports
    $world = Join-Path $RunDir "saves\$WorldName\level.dat"
    if (-not (Test-Path -LiteralPath $world)) { throw "测试世界不存在,先运行 -Phase prepare" }
    if (Test-Path -LiteralPath $latestLog) { Remove-Item -LiteralPath $latestLog -Force }
    if (Test-Path -LiteralPath $crashReports) { Remove-Item -LiteralPath $crashReports -Recurse -Force }
    $outFile = Join-Path $RunDir "runclient_launch.log"
    Remove-Item $outFile, "$outFile.err" -ErrorAction SilentlyContinue
    $p = Start-Process -FilePath (Join-Path $Root "gradlew.bat") `
        -ArgumentList ":forge-1.20.1:runClient","-Pquickplay=$WorldName","--console=plain" `
        -WorkingDirectory $Root -RedirectStandardOutput $outFile -RedirectStandardError "$outFile.err" `
        -PassThru -WindowStyle Hidden
    $deadline = (Get-Date).AddSeconds(300)
    $entered = $false
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds 5
        if (Test-Path -LiteralPath $latestLog) {
            $content = Get-Content -LiteralPath $latestLog -Raw -ErrorAction SilentlyContinue
            if ($content -match "logged in with entity") { $entered = $true; break }
            if (Get-ChildItem -LiteralPath $crashReports -Filter "*.txt" -ErrorAction SilentlyContinue) { break }
        }
        if ($p.HasExited) {
            Write-Host "runClient 退出 exit=$($p.ExitCode)"
            if (Test-Path -LiteralPath $outFile) { Get-Content -LiteralPath $outFile -Tail 25 }
            exit 1
        }
    }
    if (-not $entered) {
        Write-Host "LAUNCH_FAILED(未在时限内进入世界)"
        if (Get-ChildItem -LiteralPath $crashReports -Filter "*.txt" -ErrorAction SilentlyContinue) { Get-ChildItem $crashReports }
        exit 1
    }
    $log = Get-Content -LiteralPath $latestLog -Raw
    Write-Host "LAUNCH_OK"
    Write-Host "  AstralDiceLoaded=$($log -match 'Astral Dice mod loaded')"
    Write-Host "  MixinError=$($log -match 'Mixin apply failed|Failed to apply mixin')"
    Write-Host "  OculusPresent=$($log -match 'Oculus')"
    Write-Host "  EmbeddiumPresent=$($log -match 'Embeddium')"
    if ($Phase -ne "") { exit 0 }
}

if ($Phase -eq "stop") {
    & "$PSScriptRoot\stop_game.ps1"
    exit 0
}

if ($Phase -eq "report") {
    & "$PSScriptRoot\collect_report_forge.ps1"
    exit 0
}

Write-Host ""
Write-Host "环境就绪。TC 执行说明见 scripts\test\FLOW_1.20.1_functional.md"
Write-Host "常用注入(scripts\test\inject_input.ps1):"
Write-Host "  -Command '/give ...'   聊天命令(give 骰子/卡牌)"
Write-Host "  -Key 1 / shift-rclick  选中快捷栏 / 潜行右键自动装备"
Write-Host "  -Key h / escape         打开卡牌界面 / 关闭"
Write-Host "  -Key f2                 截图"
Write-Host "结束: powershell -File scripts\test\functional_test_forge.ps1 -Phase stop"
