# 自动化测试 - 公共路径定义(forge-1.20.1 版)
# 由各 _forge 脚本通过 . "$PSScriptRoot\common_forge.ps1" 引入(路径均从 $PSScriptRoot 推导,不硬编码)。

$Root = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent   # ...\astral_dice_multiloader
$RunDir        = Join-Path $Root "run\1.20.1"
$ModsDir       = Join-Path $RunDir "mods"
$SavesDir      = Join-Path $RunDir "saves"
$LogsDir       = Join-Path $RunDir "logs"
$LatestLog     = Join-Path $LogsDir "latest.log"
$DebugLog      = Join-Path $LogsDir "debug.log"
$KubeJSServerLog = Join-Path $LogsDir "kubejs\server.log"
$CrashReports  = Join-Path $RunDir "crash-reports"
$ScreenshotDir = Join-Path $RunDir "screenshots"
$ReportsDir    = Join-Path $Root "scripts\test\reports"
$WorldName     = "testworld"
$ClientWorld   = Join-Path $SavesDir $WorldName
$ServerWorld   = Join-Path $RunDir $WorldName

# 1.20.1 用户测试环境中的 Embeddium / Oculus 版本源(与 1.21.1 的 Sodium/Iris 对应)
$PackModsDir    = "D:\.minecraft\versions\1.20.1 模组测试\mods"
$EmbeddiumJar   = "embeddium-0.3.31+mc1.20.1.jar"
$OculusJar      = "oculus-mc1.20.1-1.8.1.jar"
$ShaderPackZip  = "ComplementaryUnbound_r5.8.1.zip"
$ShaderPackDir  = Join-Path $RunDir "shaderpacks"
$ShaderSource   = Join-Path $Root "run\1.21.1\shaderpacks\$ShaderPackZip"
