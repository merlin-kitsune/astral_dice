﻿# 自动化测试 - 向 Minecraft 窗口注入键盘输入
# 使用 PostMessage 直接投递 WM_KEYDOWN/WM_CHAR/WM_LBUTTONDOWN/WM_RBUTTONDOWN 消息,
# 绕过前台焦点与中文输入法限制(对 GLFW 窗口有效)。
# 用法:
#   inject_input.ps1 -Command "/give @p netherite_sword 1"   # 打开聊天输入命令
#   inject_input.ps1 -Key "attack"                            # 左键点击窗口中心(攻击)
#   inject_input.ps1 -Key "rclick"                            # 右键点击窗口中心(目标选择器确认)
#   inject_input.ps1 -Key "j"                                 # 按下 J 键(主动技能)
#   inject_input.ps1 -Key "w" -HoldMs 1000                    # 按住 W 键(移动验证)
param(
    [string]$Command = $null,
    [string]$Key = $null,
    [int]$HoldMs = 0,
    [switch]$NoEsc
)
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class PostInput {
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    public struct RECT { public int Left, Top, Right, Bottom; }
    public const uint WM_KEYDOWN = 0x0100;
    public const uint WM_KEYUP = 0x0101;
    public const uint WM_CHAR = 0x0102;
    public const uint WM_LBUTTONDOWN = 0x0201;
    public const uint WM_LBUTTONUP = 0x0202;
    public const uint WM_RBUTTONDOWN = 0x0204;
    public const uint WM_RBUTTONUP = 0x0205;
    public static IntPtr FindMc() {
        foreach (var p in System.Diagnostics.Process.GetProcesses()) {
            if (p.MainWindowHandle == IntPtr.Zero) continue;
            // 限定 Minecraft 客户端进程(java),排除浏览器/其他程序标题中含 "Minecraft" 的窗口
            bool isJava = p.ProcessName.IndexOf("java", System.StringComparison.OrdinalIgnoreCase) >= 0;
            var t = p.MainWindowTitle;
            if (isJava && t.IndexOf("Minecraft") >= 0 && t.IndexOf("Chrome") < 0 && t.IndexOf("Wiki") < 0) {
                return p.MainWindowHandle;
            }
        }
        return IntPtr.Zero;
    }
    public static void Key(IntPtr h, ushort vk, ushort scan) {
        IntPtr lParamDown = (IntPtr)(1 | (scan << 16));
        IntPtr lParamUp = (IntPtr)((1 << 30) | (1 | (scan << 16)));
        PostMessage(h, WM_KEYDOWN, (IntPtr)vk, lParamDown);
        PostMessage(h, WM_KEYUP, (IntPtr)vk, lParamUp);
    }
    public static void KeyDown(IntPtr h, ushort vk, ushort scan) {
        PostMessage(h, WM_KEYDOWN, (IntPtr)vk, (IntPtr)(1 | (scan << 16)));
    }
    public static void KeyUp(IntPtr h, ushort vk, ushort scan) {
        PostMessage(h, WM_KEYUP, (IntPtr)vk, (IntPtr)((1 << 30) | (1 | (scan << 16))));
    }
    public static void Char(IntPtr h, char c) {
        PostMessage(h, WM_CHAR, (IntPtr)c, (IntPtr)1);
    }
    public static void ClickCenter(IntPtr h, bool right, bool shift) {
        if (shift) { PostMessage(h, WM_KEYDOWN, (IntPtr)0xA0, (IntPtr)(1 | (0x2A << 16))); System.Threading.Thread.Sleep(120); }
        RECT r; GetWindowRect(h, out r);
        int x = (r.Right - r.Left) / 2;
        int y = (r.Bottom - r.Top) / 2;
        IntPtr lp = (IntPtr)((y << 16) | (x & 0xFFFF));
        uint down = right ? WM_RBUTTONDOWN : WM_LBUTTONDOWN;
        uint up = right ? WM_RBUTTONUP : WM_LBUTTONUP;
        PostMessage(h, down, (IntPtr)1, lp);
        System.Threading.Thread.Sleep(100);
        PostMessage(h, up, (IntPtr)0, lp);
        if (shift) { System.Threading.Thread.Sleep(100); PostMessage(h, WM_KEYUP, (IntPtr)0xA0, (IntPtr)((1 << 30) | (1 | (0x2A << 16)))); }
    }
    public static void ClickCenter(IntPtr h, bool right) { ClickCenter(h, right, false); }
}
"@

$hwnd = [PostInput]::FindMc()
if ($hwnd -eq [IntPtr]::Zero) {
    Write-Host "ERROR: 未找到 Minecraft 窗口"
    exit 1
}

# 键盘扫描码
function Get-ScanCode([ushort]$vk) {
    # 常见键的扫描码(美式布局)
    $scanMap = @{
        0x54 = 0x14   # T
        0x0D = 0x1C   # Enter
        0x1B = 0x01   # Esc
        0x45 = 0x12   # E
        0x4A = 0x24   # J
        0x48 = 0x23   # H
        0x57 = 0x11   # W
        0x71 = 0x3C   # F2
        0x72 = 0x3D   # F3
        0xBF = 0x35   # /
    }
    # 数字键 1-9
    for ($i = 0x31; $i -le 0x39; $i++) { $scanMap[$i] = 0x02 + ($i - 0x31) }
    if ($scanMap.ContainsKey($vk)) { return $scanMap[$vk] }
    return 0
}

if ($Key) {
    switch ($Key.ToLower()) {
        "attack" { [PostInput]::ClickCenter($hwnd, $false); Write-Host "已发送: 左键攻击(窗口中心)" }
        "rclick" { [PostInput]::ClickCenter($hwnd, $true);  Write-Host "已发送: 右键点击(窗口中心,确认目标)" }
        "j"      { [PostInput]::Key($hwnd, 0x4A, 0x24); Write-Host "已发送: J(主动技能/取消选择)" }
        "h"      { [PostInput]::Key($hwnd, 0x48, 0x23); Write-Host "已发送: H(打开卡牌界面)" }
        "t"      { [PostInput]::Key($hwnd, 0x54, 0x14); Write-Host "已发送: T(聊天)" }
        "shift-rclick" { [PostInput]::ClickCenter($hwnd, $true, $true); Write-Host "已发送: 潜行右键(窗口中心)" }
        "e"      { [PostInput]::Key($hwnd, 0x45, 0x12); Write-Host "已发送: E(物品栏)" }
        "escape" { [PostInput]::Key($hwnd, 0x1B, 0x01); Write-Host "已发送: Esc" }
        "1" { [PostInput]::Key($hwnd, 0x31, 0x02); Write-Host "已发送: 1(快捷栏槽1)" }
        "2" { [PostInput]::Key($hwnd, 0x32, 0x03); Write-Host "已发送: 2(快捷栏槽2)" }
        "3" { [PostInput]::Key($hwnd, 0x33, 0x04); Write-Host "已发送: 3(快捷栏槽3)" }
        "4" { [PostInput]::Key($hwnd, 0x34, 0x05); Write-Host "已发送: 4(快捷栏槽4)" }
        "5" { [PostInput]::Key($hwnd, 0x35, 0x06); Write-Host "已发送: 5(快捷栏槽5)" }
        "6" { [PostInput]::Key($hwnd, 0x36, 0x07); Write-Host "已发送: 6(快捷栏槽6)" }
        "7" { [PostInput]::Key($hwnd, 0x37, 0x08); Write-Host "已发送: 7(快捷栏槽7)" }
        "8" { [PostInput]::Key($hwnd, 0x38, 0x09); Write-Host "已发送: 8(快捷栏槽8)" }
        "9" { [PostInput]::Key($hwnd, 0x39, 0x0A); Write-Host "已发送: 9(快捷栏槽9)" }
        "enter"  { [PostInput]::Key($hwnd, 0x0D, 0x1C); Write-Host "已发送: Enter(确认目标)" }
        "f2"     { [PostInput]::Key($hwnd, 0x71, 0x3C); Write-Host "已发送: F2(截图)" }
        "f3"     { [PostInput]::Key($hwnd, 0x72, 0x3D); Write-Host "已发送: F3(调试界面)" }
        "w"      {
            [PostInput]::KeyDown($hwnd, 0x57, 0x11)
            Start-Sleep -Milliseconds $(if ($HoldMs -gt 0) { $HoldMs } else { 1000 })
            [PostInput]::KeyUp($hwnd, 0x57, 0x11)
            Write-Host "已发送: W 按住 $(if ($HoldMs -gt 0) { $HoldMs } else { 1000 })ms(移动)"
        }
        default  { Write-Host "未知按键: $Key" }
    }
}
if ($Command) {
    # -NoEsc:跳过开头的 Esc Esc(用于目标选择模式激活期间——此时 Esc 会取消选择,
    #  且 / 命令聊天已被白名单放行,直接开聊天即可)
    if (-not $NoEsc) {
        # 确保聊天彻底关闭(Esc 两次,避免聊天残留导致命令累积)
        [PostInput]::Key($hwnd, 0x1B, 0x01)
        Start-Sleep -Milliseconds 150
        [PostInput]::Key($hwnd, 0x1B, 0x01)
        Start-Sleep -Milliseconds 200
    }
    # 用斜杠键(/键)打开聊天:斜杠键本身会带一个 / 前缀,不用 T 键
    [PostInput]::Key($hwnd, 0xBF, 0x35)
    Start-Sleep -Milliseconds 800         # 等待聊天打开
    $text = $Command
    if ($text.StartsWith("/")) { $text = $text.Substring(1) }  # 斜杠键已提供 /
    foreach ($ch in $text.ToCharArray()) { [PostInput]::Char($hwnd, $ch) }
    Start-Sleep -Milliseconds 300         # 等待字符处理完毕
    [PostInput]::Key($hwnd, 0x0D, 0x1C)   # Enter 发送命令
    Write-Host "已发送命令: $Command"
}
