# 自动化测试 - 收集日志/截图并生成报告骨架
# 用法: powershell -ExecutionPolicy Bypass -File scripts\test\collect_report.ps1
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

$date = Get-Date -Format "yyyy-MM-dd"
$reportDir = Join-Path $ReportsDir "${date}_targetselector"
if (-not (Test-Path -LiteralPath $reportDir)) { New-Item -ItemType Directory -Path $reportDir | Out-Null }

$targets = @(
    @{ n = "latest.log";  p = $LatestLog },
    @{ n = "kubejs_server.log"; p = $KubeJSServerLog },
    @{ n = "runclient_launch.log"; p = Join-Path $RunDir "runclient_launch.log" }
)
foreach ($t in $targets) {
    if (Test-Path -LiteralPath $t.p) { Copy-Item -LiteralPath $t.p -Destination (Join-Path $reportDir $t.n) -Force }
}
if (Test-Path -LiteralPath $ScreenshotDir) {
    Get-ChildItem -LiteralPath $ScreenshotDir -Filter "*.png" -ErrorAction SilentlyContinue |
        Copy-Item -Destination (Join-Path $reportDir "screenshots") -Force -ErrorAction SilentlyContinue
}
if (Test-Path -LiteralPath $CrashReports) {
    Copy-Item -LiteralPath $CrashReports -Destination $reportDir -Recurse -Force
}

$report = Join-Path $reportDir "report.md"
$markers = @()
if (Test-Path -LiteralPath $LatestLog) {
    $markers = Get-Content -LiteralPath $LatestLog | Select-String -Pattern "\[Astral Dice\]\[TargetSelection" | ForEach-Object { $_.Line }
}
$markerCount = $markers.Count
$hasCrash = Get-ChildItem -LiteralPath $CrashReports -Filter "*.txt" -ErrorAction SilentlyContinue | Measure-Object | Select-Object -ExpandProperty Count
$content = @"
# Astral Dice 目标选择器自动化测试报告 — $date

- 分支: 1.21.1-targetselector
- 环境: 仓库根 run/1.21.1 (dev 本体) + Sodium $SodiumJar + Iris $IrisJar
- 结果: 待人工/会话补充 TC1~TC13 断言

## 目标选择标记($markerCount 条)
``````
$($markers -join "`n")
``````

## 崩溃报告
- crash-reports 文件数: $hasCrash

## 截图
见 ./screenshots(F2 生成)
"@
Set-Content -LiteralPath $report -Value $content -Encoding utf8
Write-Host "REPORT_OK: $report"
