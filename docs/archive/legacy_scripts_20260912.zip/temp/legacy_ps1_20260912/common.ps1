﻿# 自动化测试 - 公共路径定义
# 由各脚本通过 . "$PSScriptRoot\common.ps1" 引入(路径均从 $PSScriptRoot 推导,不硬编码)。

$Root = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent   # ...\astral_dice_multiloader
$RunDir        = Join-Path $Root "run\1.21.1"
$ModsDir       = Join-Path $RunDir "mods"
$SavesDir      = Join-Path $RunDir "saves"
$LogsDir       = Join-Path $RunDir "logs"
$LatestLog     = Join-Path $LogsDir "latest.log"
$KubeJSServerLog = Join-Path $LogsDir "kubejs\server.log"
$CrashReports  = Join-Path $RunDir "crash-reports"
$ScreenshotDir = Join-Path $RunDir "screenshots"
$ReportsDir    = Join-Path $Root "scripts\test\reports"
$WorldName     = "testworld"
$ClientWorld   = Join-Path $SavesDir $WorldName
$ServerWorld   = Join-Path $RunDir $WorldName

# 整合包(用户测试环境)中的 Sodium / Iris / ModernFix 版本源
$PackModsDir  = "D:\.minecraft\versions\狐の航空学 Voxy Edition\mods"
$SodiumJar    = "sodium-neoforge-0.8.13+mc1.21.1.jar"
$IrisJar      = "iris-neoforge-1.8.14-beta.1+mc1.21.1.jar"
$ModernFixJar = "modernfix-neoforge-5.27.24+mc1.21.1.jar"
