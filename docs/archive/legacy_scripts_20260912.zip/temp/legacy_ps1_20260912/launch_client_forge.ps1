﻿# 自动化测试 - 启动 runClient 快速进入 testworld 并等待就绪(forge-1.20.1 版)
# 1. 清空 latest.log / crash-reports
# 2. 后台启动 gradlew :forge-1.20.1:runClient -Pquickplay=testworld
# 3. 基础等待 30s 后轮询 ModernFix 的 "Total time to load game and open world was" 日志(每 15s 一次)
# 4. 输出 Embeddium/Oculus 加载情况(兼容性断言)
# 5. 进入世界后自动执行 /publish 25565 开放局域网(minecraft-mcp 第二玩家 LLMBot 连接)
# 用法: powershell -ExecutionPolicy Bypass -File scripts\test\launch_client_forge.ps1
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common_forge.ps1"
$root = $Root
$run = $RunDir
$worldName = $WorldName
$latestLog = $LatestLog
$crashReports = $CrashReports

if (-not (Test-Path -LiteralPath (Join-Path $run "saves\$worldName\level.dat"))) {
    Write-Host "ERROR: 测试世界不存在,请先运行 prepare_world_forge.ps1"
    exit 1
}
if (Test-Path -LiteralPath $latestLog) { Remove-Item -LiteralPath $latestLog -Force }
if (Test-Path -LiteralPath $crashReports) { Remove-Item -LiteralPath $crashReports -Recurse -Force }
if (-not (Test-Path -LiteralPath (Join-Path $run "screenshots"))) { New-Item -ItemType Directory -Path (Join-Path $run "screenshots") | Out-Null }

$outFile = Join-Path $run "runclient_launch.log"
Write-Host "启动 runClient(quickplay=$worldName)..."
$proc = Start-Process -FilePath (Join-Path $root "gradlew.bat") `
    -ArgumentList ":forge-1.20.1:runClient","-Pquickplay=$worldName","--console=plain" `
    -WorkingDirectory $root -RedirectStandardOutput $outFile -RedirectStandardError "$outFile.err" `
    -PassThru -WindowStyle Hidden

# 启动验证:基础等待 30s,然后轮询 ModernFix 加载完成日志(游戏与世界均加载完成后输出
# "Total time to load game and open world was ... seconds");未出现则每 15s 再检测一次。
Start-Sleep -Seconds 30
$deadline = (Get-Date).AddSeconds(180)
$entered = $false
while ((Get-Date) -lt $deadline) {
    if (Test-Path -LiteralPath $latestLog) {
        try {
            $fs = [System.IO.File]::Open($latestLog, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
            $reader = New-Object System.IO.StreamReader($fs, [System.Text.Encoding]::UTF8)
            $content = $reader.ReadToEnd()
            $reader.Close(); $fs.Close()
            if ($content -match "Total time to load game and open world was") { $entered = $true; break }
            if (Get-ChildItem -LiteralPath $crashReports -Filter "*.txt" -ErrorAction SilentlyContinue) {
                Write-Host "检测到崩溃报告!"
                break
            }
        } catch { }
    }
    if ($proc.HasExited) {
        Write-Host "runClient 进程已退出(exit=$($proc.ExitCode)),可能启动失败"
        if (Test-Path -LiteralPath $outFile) { Get-Content -LiteralPath $outFile -Tail 30 }
        exit 1
    }
    Start-Sleep -Seconds 15
}

if (-not $entered) {
    Write-Host "LAUNCH_FAILED(未在时限内进入世界)"
    exit 1
}

# 兼容性断言:dev runClient 按设计不装渲染模组(见 install_test_mods_forge.ps1 说明),
# 重点断言本模组 KeyboardHandlerMixin 已应用、无 Mixin 错误、无崩溃;Embeddium/Oculus 若出现仅提示
$logContent = ""
if (Test-Path -LiteralPath $latestLog) { $logContent = Get-Content -LiteralPath $latestLog -Raw }
$embeddium = $logContent -match "Embeddium"
$oculus    = $logContent -match "Oculus"
$ownMixin  = $logContent -match "KeyboardHandlerMixin|astral_dice.mixins"
Write-Host "EMBEDDIUM_LOADED=$embeddium"
Write-Host "OCULUS_LOADED=$oculus"
Write-Host "OWN_MIXIN_APPLIED=$ownMixin"
if ($logContent -match "Mixin apply failed|Mixin apply error|Failed to apply mixin") {
    Write-Host "MIXIN_ERROR_DETECTED"
}
if (Get-ChildItem -LiteralPath $crashReports -Filter "*.txt" -ErrorAction SilentlyContinue) {
    Write-Host "CRASH_REPORTS_PRESENT"
}
if (-not $ownMixin) {
    Write-Host "LAUNCH_WARN(本模组 Mixin 未确认应用)"
    exit 2
}
# 进入世界后自动开放局域网(固定端口 25565),供 minecraft-mcp 第二玩家(LLMBot)连接
& "$PSScriptRoot\publish_lan_forge.ps1"
if ($LASTEXITCODE -ne 0) {
    Write-Host "LAUNCH_OK_BUT_PUBLISH_FAILED(/publish 25565 未完成,双人 TC 不可用)"
    exit 3
}
Write-Host "LAUNCH_OK(已进入世界, ownMixin=$ownMixin, Embeddium=$embeddium, Oculus=$oculus, LAN_PUBLISHED=25565)"
exit 0
