﻿# 自动化测试 - 安装测试用 Sodium + Iris(复制自整合包,幂等)
# 用于验证目标选择器高亮渲染在 Sodium/Iris 下的兼容性。
# 源文件按通配匹配(整合包中 Sodium 文件名带 "[钠] " 前缀),目标统一规范化命名。
# 用法: powershell -ExecutionPolicy Bypass -File scripts\test\install_test_mods.ps1
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common.ps1"

function Copy-ModByPattern([string]$pattern, [string]$targetName) {
    $srcFile = Get-ChildItem -LiteralPath $PackModsDir -Filter $pattern -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match "neoforge" } | Select-Object -First 1
    if ($null -eq $srcFile) {
        Write-Host "WARN: 整合包未找到匹配 $pattern 的模组(跳过;若需验证兼容请手动放入 $ModsDir)"
        return $false
    }
    $dst = Join-Path $ModsDir $targetName
    $need = $true
    if (Test-Path -LiteralPath $dst) {
        $d = (Get-Item -LiteralPath $dst).LastWriteTimeUtc
        if ($d -ge $srcFile.LastWriteTimeUtc) { $need = $false }
    }
    if ($need) {
        Copy-Item -LiteralPath $srcFile.FullName -Destination $dst -Force
        Write-Host "已安装: $targetName (来自 $($srcFile.Name))"
    } else {
        Write-Host "已存在且为最新: $targetName"
    }
    return $true
}

if (-not (Test-Path -LiteralPath $ModsDir)) { New-Item -ItemType Directory -Path $ModsDir | Out-Null }
$sodiumOk = Copy-ModByPattern "*sodium-neoforge*0.8.13*.jar" $SodiumJar
$irisOk   = Copy-ModByPattern "*iris-neoforge*1.8.14*.jar"    $IrisJar
$modernFixOk = Copy-ModByPattern "*modernfix-neoforge*5.27.24*.jar" $ModernFixJar

if ($sodiumOk -and $irisOk -and $modernFixOk) {
    Write-Host "TEST_MODS_OK"
    exit 0
} else {
    Write-Host "TEST_MODS_WARN(部分模组缺失)"
    exit 1
}
