﻿# 自动化测试 - 将已进入的单人世界自动开放为局域网(固定端口 25565) [forge-1.20.1 版]
# 用途: minecraft-mcp(mineflayer 机器人 LLMBot)需要以第二玩家身份连入 localhost:25565,
#       双人/多玩家类 TC(S9 等)依赖此步骤。launch_client_forge.ps1 进入世界后会自动调用本脚本。
# 前置:
#   - runClient 已进入 testworld(prepare_world_forge.ps1 已设 allow-cheats,否则 /publish 不可用)
#   - 系统输出法为「英语(美国)」(inject_input.ps1 按美式键码注入)
# 用法: powershell -ExecutionPolicy Bypass -File scripts\test\publish_lan_forge.ps1
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common_forge.ps1"

$port = 25565
Write-Host "===== 阶段: 打开局域网联机(端口 $port) ====="
# 等待世界画面稳定(launch 轮询到 logged in with entity 后仍需短暂就绪)
Start-Sleep -Seconds 2
& "$PSScriptRoot\inject_input.ps1" -Command "/publish $port"
if ($LASTEXITCODE -ne 0) {
    Write-Host "PUBLISH_FAILED(注入 /publish 失败: 未找到 Minecraft 窗口或注入异常)"
    exit 1
}

# /publish 的反馈主要是聊天栏系统消息,不一定写入 latest.log;等待片刻后软断言,
# 硬性验证由会话内 minecraft MCP 确认 LLMBot 是否已加入(BOT_JOINED)。
Start-Sleep -Seconds 4
$evidence = ""
if (Test-Path -LiteralPath $LatestLog) {
    $content = Get-Content -LiteralPath $LatestLog -Raw -ErrorAction SilentlyContinue
    if ($content -match "(?i)publish|open to lan|local network|局域网|port\s*$port|25565") {
        $evidence = $Matches[0]
    }
}
if ($evidence) {
    Write-Host "PUBLISH_OK(已执行 /publish $port, 日志痕迹: $evidence)"
} else {
    Write-Host "PUBLISH_SENT(已执行 /publish $port; LAN 连通性待 minecraft-mcp 机器人验证)"
}
exit 0
