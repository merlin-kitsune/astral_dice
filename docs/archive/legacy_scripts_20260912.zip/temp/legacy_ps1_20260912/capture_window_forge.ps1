# 捕获 Minecraft 窗口内容为 PNG(用于视觉断言)
# 用法: powershell -File scripts\test\capture_window_forge.ps1 [-Out temp\shot.png]
param([string]$Out = "F:\MCProject\astral_dice_multiloader\temp\game_window.png")
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public struct R2{public int L,T,Rt,B;} public class W2{[DllImport("user32.dll")]public static extern bool GetWindowRect(IntPtr h,out R2 r);}'
$h = [IntPtr]::Zero
foreach ($p in Get-Process java) { if ($p.MainWindowTitle -match 'Minecraft') { $h = $p.MainWindowHandle; break } }
if ($h -eq [IntPtr]::Zero) { Write-Host "ERROR: no Minecraft window"; exit 1 }
$r = New-Object R2
[W2]::GetWindowRect($h, [ref]$r) | Out-Null
$w = $r.Rt - $r.L; $ht = $r.B - $r.T
$b = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($b)
$g.CopyFromScreen($r.L, $r.T, 0, 0, $b.Size)
$b.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
Write-Host "SAVED: $Out (${w}x${ht} at $($r.L),$($r.T))"
