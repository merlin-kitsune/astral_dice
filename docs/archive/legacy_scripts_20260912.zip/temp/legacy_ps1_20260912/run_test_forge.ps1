﻿# 自动化测试 - 主流程入口(forge-1.20.1 目标选择器)
# 阶段:
#   -Phase build   : 构建子项目(pushToDevRun 自动部署 jar 到 run mods)+ 安装 Embeddium/Oculus/光影
#   -Phase prepare : 重建超平坦测试世界(testworld,允许命令)
#   -Phase launch  : 启动 runClient(quickplay=testworld)并等待进入世界
#                    (进入后自动 /publish 25565 开放局域网,供 minecraft-mcp 第二玩家 LLMBot 连接)
#   -Phase stop    : 关闭游戏
#   -Phase report  : 收集日志/截图到 scripts/test/reports/<日期>_targetselector_forge.md
#   无参数       : 依次执行 build → prepare → launch(单入口),随后打印 TC 驱动说明
#
# 注意:TC 级注入/截图/视觉校验由 Harness 会话驱动(inject_input.ps1 + F2 截图 + LOGGER 断言);
#      双人 TC 使用 minecraft-mcp(LLMBot,localhost:25565),会话内用 mcp__minecraft__* 验证。
#      本脚本负责环境准备与收尾,保证 runClient 仅经本流程启动(AGENTS 自动化测试子配置)。
param(
    [ValidateSet("build","prepare","launch","stop","report","")][string]$Phase = ""
)
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common_forge.ps1"

function Invoke-Phase([string]$name, [scriptblock]$block) {
    Write-Host "===== 阶段: $name ====="
    & $block
    if ($LASTEXITCODE -ne 0) { throw "阶段 $name 失败(exit=$LASTEXITCODE)" }
}

if ($Phase -eq "build" -or $Phase -eq "") {
    Invoke-Phase "build" { & "$PSScriptRoot\run_gradle_forge.ps1" -Task ":forge-1.20.1:build" }
    Invoke-Phase "install_test_mods" { & "$PSScriptRoot\install_test_mods_forge.ps1" }
    if ($Phase -ne "") { exit 0 }
}
if ($Phase -eq "prepare" -or $Phase -eq "") {
    Invoke-Phase "prepare" { & "$PSScriptRoot\prepare_world_forge.ps1" }
    if ($Phase -ne "") { exit 0 }
}
if ($Phase -eq "launch" -or $Phase -eq "") {
    Invoke-Phase "launch" { & "$PSScriptRoot\launch_client_forge.ps1" }
    if ($Phase -ne "") { exit 0 }
}
if ($Phase -eq "stop") {
    & "$PSScriptRoot\stop_game.ps1"
    exit 0
}
if ($Phase -eq "report") {
    & "$PSScriptRoot\collect_report_forge.ps1"
    exit 0
}

if ($Phase -eq "") {
    Write-Host ""
    Write-Host "环境就绪,游戏已启动(LAN 已开放: /publish 25565)。接下来由 Harness 会话驱动 TC1~TC13(forge-1.20.1):"
    Write-Host "  - 注入: scripts\test\inject_input.ps1 -Key <rclick|enter|escape|j|f2|w|e|t|f3>"
    Write-Host "  - 命令: scripts\test\inject_input.ps1 -Command '/astral_dice targetselect enemy'"
    Write-Host "  - 截图: F2 → $ScreenshotDir (视觉校验)"
    Write-Host "  - 断言: $LatestLog 中 [Astral Dice][TargetSelection*] 标记;crash-reports 为空"
    Write-Host "  - 双人: 会话内调用 minecraft MCP(mcp__minecraft__*)确认 LLMBot 已加入(BOT_JOINED)后执行 S9 等双人 TC"
    Write-Host "  - 结束: powershell -File scripts\test\run_test_forge.ps1 -Phase stop"
    Write-Host "  - 报告: powershell -File scripts\test\run_test_forge.ps1 -Phase report"
}
