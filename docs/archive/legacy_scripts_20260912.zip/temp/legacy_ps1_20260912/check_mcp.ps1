﻿# 自动化测试 - computer-control-mcp 本地安装自检
# 说明:连接器配置由 DeepSeek Harness 的 mcp_connector_configure 创建(custom-computer_control,stdio);
#      会话内用 mcp_connector_status / mcp_connector_tools_list 验证(TC13)。
#      本脚本仅验证本地二进制与运行环境。
# 用法: powershell -ExecutionPolicy Bypass -File scripts\test\check_mcp.ps1
$ErrorActionPreference = "Continue"
$exe = "C:\Users\xmace\.local\bin\computer-control-mcp.exe"
if (-not (Test-Path -LiteralPath $exe)) {
    Write-Host "MCP_BINARY_MISSING: $exe"
    exit 1
}
$help = & $exe --help 2>&1 | Select-Object -First 5
Write-Host "MCP_BINARY_OK: $exe"
$help | ForEach-Object { Write-Host "  $_" }
Write-Host "MCP_ENV_SCREENSHOT_DIR=$env:COMPUTER_CONTROL_MCP_SCREENSHOT_DIR"
Write-Host "MCP_ENV_WGC_PATTERNS=$env:COMPUTER_CONTROL_MCP_WGC_PATTERNS"
Write-Host "CHECK_MCP_DONE(连接状态请在 Harness 会话内用 mcp_connector_status 确认)"
