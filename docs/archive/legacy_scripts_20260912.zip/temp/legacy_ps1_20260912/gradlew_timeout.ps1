﻿# gradlew_timeout.ps1 — 带超时强退的 Gradle 构建执行器(遵循 AGENTS.md Watchdog 规则)
# 用法: powershell -File scripts/test/gradlew_timeout.ps1 -GradleArgs ":neoforge-1.21.1:build" [-TimeoutSec 60]
param(
    [Parameter(Mandatory=$true)][string]$GradleArgs,
    [int]$TimeoutSec = 60,
    [switch]$NoDaemonStop
)
$ErrorActionPreference = "Stop"
$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$LogDir = Join-Path $RepoRoot "temp"
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogFile = Join-Path $LogDir ("gradle_" + $stamp + ".log")

Write-Output "GRADLE_ARGS: $GradleArgs"
Write-Output "TIMEOUT_SEC: $TimeoutSec"
Write-Output "LOG: $LogFile"

$proc = Start-Process -FilePath "cmd.exe" `
    -ArgumentList "/c", "gradlew.bat $GradleArgs --console=plain" `
    -WorkingDirectory $RepoRoot `
    -RedirectStandardOutput $LogFile -RedirectStandardError "$LogFile.err" `
    -PassThru -NoNewWindow

$timedOut = -not $proc.WaitForExit($TimeoutSec * 1000)
if ($timedOut) {
    Write-Output "TIMEOUT: process tree still running after $TimeoutSec s, force killing (PID $($proc.Id))..."
    taskkill /PID $proc.Id /T /F 2>&1 | Out-Null
    Start-Sleep -Seconds 2
}

if (-not $NoDaemonStop) {
    try { & (Join-Path $RepoRoot "gradlew.bat") --stop 2>&1 | Out-Null } catch {}
}

if (Test-Path "$LogFile.err") { Get-Content "$LogFile.err" | Add-Content $LogFile; Remove-Item "$LogFile.err" -Force }

$log = ""
if (Test-Path $LogFile) { $log = Get-Content $LogFile -Raw }

# --- 结果验证: 日志关键字 ---
$hasSuccess = $log -match "BUILD SUCCESS"
$hasFailed  = $log -match "BUILD FAILED|error:|ERROR\]"
Write-Output ("LOG_BUILD_SUCCESS: {0}" -f [bool]$hasSuccess)
Write-Output ("LOG_BUILD_FAILED:  {0}" -f [bool]$hasFailed)

# --- 结果验证: 产物时间戳(5 分钟内生成/更新的 jar) ---
$cut = (Get-Date).AddMinutes(-5)
$artifacts = Get-ChildItem -Path (Join-Path $RepoRoot "*uild\libs\*.jar") -ErrorAction SilentlyContinue |
    Where-Object { $_.LastWriteTime -gt $cut }
if ($artifacts) {
    Write-Output "RECENT_ARTIFACTS:"
    $artifacts | ForEach-Object { Write-Output ("  {0}  {1}" -f $_.LastWriteTime.ToString("HH:mm:ss"), $_.FullName.Replace($RepoRoot, ".")) }
} else {
    Write-Output "RECENT_ARTIFACTS: (none within 5 min)"
}

Write-Output "---- LOG TAIL (last 25 lines) ----"
if (Test-Path $LogFile) { Get-Content $LogFile -Tail 25 }

if ($hasSuccess) { Write-Output "RESULT: BUILD_OK" }
elseif ($timedOut -and $artifacts) { Write-Output "RESULT: TIMEOUT_BUT_ARTIFACTS_PRESENT (verify manually)" }
elseif ($timedOut) { Write-Output "RESULT: TIMEOUT_NO_SUCCESS" }
else { Write-Output "RESULT: BUILD_FAILED" }
