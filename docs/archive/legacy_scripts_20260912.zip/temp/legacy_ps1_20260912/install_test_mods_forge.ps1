# 自动化测试 - 安装测试用 Embeddium + Oculus(用户生产环境专用,幂等)
# 说明:MDG Legacy 的 forge dev 环境为 mojmap 命名,Embeddium/Oculus(SRG 产物)的 mixin
#       refmap 在 dev 无法解析(直接放 run/mods 或放 classpath 均 Mixin apply failed),
#       因此 **dev runClient 不使用渲染模组**(原版渲染管线跑功能测试)。
#       本脚本只保证用户生产环境(D:\\.minecraft\\versions\\1.20.1 模组测试)的渲染栈就绪:
#       Embeddium+Oculus+ComplementaryUnbound+无 IMBlocker+shader 配置,供 TC11 渲染兼容人工验证。
# 用法: powershell -ExecutionPolicy Bypass -File scripts\test\install_test_mods_forge.ps1
$ErrorActionPreference = "Stop"
. "$PSScriptRoot\common_forge.ps1"

if (-not (Test-Path -LiteralPath $PackModsDir)) {
    Write-Host "ERROR: 用户测试环境不存在: $PackModsDir"
    exit 1
}

# 1. IMBlocker 必须不在 mods 中(与 1.21.1 一致;已移入 __disabled__)
$imblocker = Get-ChildItem -LiteralPath $PackModsDir -Filter "*.jar" -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -match "IMBlocker" } | Select-Object -First 1
if ($null -ne $imblocker) {
    Write-Host "WARN: 用户环境仍含 IMBlocker: $($imblocker.Name)(测试环境要求移除)"
    Write-Host "  -> 请移至 $PackModsDir\..\__disabled__\ 或删除"
} else {
    Write-Host "IMBLOCKER_ABSENT=OK"
}

# 2. Embeddium / Oculus 存在性
$embeddium = Get-ChildItem -LiteralPath $PackModsDir -Filter "*embeddium*.jar" -ErrorAction SilentlyContinue | Select-Object -First 1
$oculus    = Get-ChildItem -LiteralPath $PackModsDir -Filter "*oculus*.jar" -ErrorAction SilentlyContinue | Select-Object -First 1
Write-Host "EMBEDDIUM=$($embeddium.Name)"
Write-Host "OCULUS=$($oculus.Name)"

# 3. 光影包 + 配置
$shaderPack = Join-Path $PackModsDir "..\shaderpacks\$ShaderPackZip"
if (Test-Path -LiteralPath $shaderPack) {
    Write-Host "SHADERPACK_OK=$ShaderPackZip"
} else {
    Write-Host "WARN: 用户环境缺光影包: $shaderPack"
}
$cfgDir = Join-Path $PackModsDir "..\config"
foreach ($cfgName in @("oculus.properties", "iris.properties")) {
    $cfg = Join-Path $cfgDir $cfgName
    if (Test-Path -LiteralPath $cfg) {
        $content = Get-Content -LiteralPath $cfg -Raw
        if ($content -match "shaderPack=$ShaderPackZip") { Write-Host "$cfgName OK(shader 已设置)" }
        else { Write-Host "WARN: $cfgName 未设置 shaderPack" }
    } else {
        Write-Host "WARN: 缺 $cfgName"
    }
}

if ($null -ne $embeddium -and $null -ne $oculus) {
    Write-Host "TEST_MODS_OK(用户生产环境渲染栈就绪;dev 环境按设计不装渲染模组)"
    exit 0
} else {
    Write-Host "TEST_MODS_WARN(用户环境缺 Embeddium 或 Oculus)"
    exit 1
}
