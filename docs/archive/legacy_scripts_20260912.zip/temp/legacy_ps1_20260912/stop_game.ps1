﻿# 自动化测试 - 停止游戏客户端与相关进程
Get-Process -Name "java" -ErrorAction SilentlyContinue | Where-Object { $_.Path -match "zulu|java" } | Stop-Process -Force -ErrorAction SilentlyContinue
Get-Process -Name "gradle" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Write-Host "游戏进程已停止"
