$out = 'F:\MCProject\astral_dice_multiloader\temp\recycle.txt'
$L = New-Object System.Collections.Generic.List[string]
function W($s) { $script:L.Add([string]$s) }

W ("=== recycle bin decode {0} ===" -f (Get-Date -Format o))

$sids = Get-ChildItem 'F:\$RECYCLE.BIN' -Directory -Force -ErrorAction SilentlyContinue
foreach ($s in $sids) {
    W ""
    W ("--- SID dir: {0} ---" -f $s.FullName)
    $iFiles = Get-ChildItem $s.FullName -Filter '$I*' -Force -ErrorAction SilentlyContinue |
              Sort-Object LastWriteTime -Descending
    W ("`$I count = {0}" -f $iFiles.Count)
    $n = 0
    foreach ($f in $iFiles) {
        $n++
        if ($n -gt 60) { W "  ... (more omitted)"; break }
        try {
            $b = [System.IO.File]::ReadAllBytes($f.FullName)
            $ver  = [BitConverter]::ToInt64($b, 0)
            $size = [BitConverter]::ToInt64($b, 8)
            $ft   = [BitConverter]::ToInt64($b, 16)
            $len  = [BitConverter]::ToInt32($b, 24)
            $time = [DateTime]::FromFileTime($ft)
            $name = [System.Text.Encoding]::Unicode.GetString($b, 28, [Math]::Max(0, $b.Length - 28)).TrimEnd([char]0)
            W ("  {0:yyyy-MM-dd HH:mm:ss.fff}  size={1,-7}  {2}" -f $time, $size, $name)
        } catch { W ("  ERR reading {0}: {1}" -f $f.Name, $_) }
    }
}

W ""
W "=== 最近 10 分钟内、名字/路径含 refs 或 deep 的回收项统计 ==="
$cut = (Get-Date).AddMinutes(-10)
$all = Get-ChildItem 'F:\$RECYCLE.BIN' -Filter '$I*' -Recurse -Force -ErrorAction SilentlyContinue |
       Where-Object { $_.LastWriteTime -gt $cut }
W ("count(last 10 min) = {0}" -f @($all).Count)

W ""
W "=== DONE ==="
$L -join "`r`n" | Set-Content -LiteralPath $out -Encoding utf8
