$out = 'F:\MCProject\astral_dice_multiloader\temp\flt.txt'
$L = New-Object System.Collections.Generic.List[string]
function W($s) { $script:L.Add([string]$s) }

W ("=== flt probe {0} ===" -f (Get-Date -Format o))

$S = 'C:\Windows\System32'
try {
  $adm = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
  W ("IsAdmin = $adm")
} catch { W "ERR admin check: $_" }

try { W "--- whoami /groups ---"; $o = & "$S\whoami.exe" /groups 2>&1; W (($o | ForEach-Object { "$_" }) -join "`n") } catch { W "ERR whoami: $_" }

try { W ""; W "--- fltmc filters ---";     $o = & "$S\fltmc.exe" filters 2>&1;     W (($o | ForEach-Object { "$_" }) -join "`n") } catch { W "ERR fltmc filters: $_" }
try { W ""; W "--- fltmc instances ---";   $o = & "$S\fltmc.exe" instances 2>&1;   W (($o | ForEach-Object { "$_" }) -join "`n") } catch { W "ERR fltmc instances: $_" }
try { W ""; W "--- fltmc volumes ---";     $o = & "$S\fltmc.exe" volumes 2>&1;     W (($o | ForEach-Object { "$_" }) -join "`n") } catch { W "ERR fltmc volumes: $_" }

try {
  W ""
  W "--- loaded kernel drivers (file system / filter related) ---"
  $d = Get-CimInstance Win32_SystemDriver -ErrorAction Stop | Where-Object { $_.State -eq 'Running' -and $_.PathName -match 'flt|fs|file|kav|kl|sym|sec|cld|wdf|bind|ntfs|search|cloud|sync' }
  W (($d | Select-Object Name,DisplayName,PathName | Sort-Object Name | Format-Table -AutoSize | Out-String -Width 240))
} catch { W "ERR drivers: $_" }

try {
  W ""
  W "--- minifilter-like services in registry ---"
  $k = Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services' -ErrorAction SilentlyContinue
  $rows = foreach ($x in $k) {
    $p = Get-ItemProperty $x.PSPath -ErrorAction SilentlyContinue
    if ($p.Type -eq 2 -and ($p.Group -match 'FSFilter' -or $p.DependOnService -match 'FltMgr' -or $p.SupportedFeatures -ne $null)) {
      "{0,-28} group={1,-22} alt={2}" -f $x.PSChildName, $p.Group, ($p.Altitude)
    }
  }
  W (($rows | Sort-Object) -join "`n")
} catch { W "ERR minifilter reg: $_" }

W ""
W "=== DONE ==="
$L -join "`r`n" | Set-Content -LiteralPath $out -Encoding utf8
